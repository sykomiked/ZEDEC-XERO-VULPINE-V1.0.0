/* kernel_main_arm32.c — ARM32 (AArch32) kernel entry point for ZEDEC XERO pqOS.
 *
 * Rewritten 2026-08-08 to use the CURRENT subsystem APIs (the previous version
 * called an init API — m5_kernel_init/isf_init/*_device_init/desktop_init/… — that
 * no longer exists). This mirrors kernel_main_riscv.c's proven init sequence, with
 * the arm32 arch wrappers (PL011 UART + WFI event loop). Core bring-up profile.
 *
 * Author: H.M. Michael-Laurence: Curzi (c)
 * Copyright (c) 2024-2026 Michael Laurence Curzi and 36N9 Genetics, LLC
 * SPDX-License-Identifier: Apache-2.0
 */
#include "arm32_arch.h"

/* Arch UART (kernel/arch/arm32/uart_pl011.c) */
extern void uart_init(void);
extern void uart_puts(const char *s);
extern void uart_dec(uint32_t val);

extern void license_print_all(void);

/* Current M5 + platform subsystem APIs (same set kernel_main_riscv.c links). */
#include "../src/oseq/oseq_core.h"
#include "../src/rmag/rmag_core.h"
#include "../src/lpres/lpres_core.h"
#include "../src/iphase/iphase_core.h"
#include "../src/choice/choice_core.h"
#include "../src/phase_coord/phase_coordinator.h"
#include "../src/predictive/predictive_model.h"
#include "../src/finance/triple_ledger.h"
#include "../src/finance/financial.h"
#include "../src/finance/rails.h"
#include "../src/finance/crypto_bridge.h"
#include "../src/identity/identity.h"
#include "../src/quantum/quantum_device.h"
#include "../src/hardware/rtl_device.h"
#include "../src/net/jdr_piratenet.h"
#include "../src/vino/vino.h"
#include "../src/vena/vena.h"
#include "../src/holographic/holo.h"

/* THE DECLARATION-GRAPH BOOT GATE, shared with the other four architectures.
 * kernel/src/modbind/zxv_decl_gate.c holds the whole sequence; this main calls
 * it. Before that extraction the gate was inline in kernel_main_arm64.c and so
 * ran on arm64 ALONE -- this file booted without ever asking whether its
 * declaration graph was sound.
 *
 * This main is the reason the gate takes ONE puts callback and no put_dec: it
 * has no put_dec to give. (uart_dec above is the arch driver's, and it is
 * uint32_t-only.) The gate formats its own decimals with uint32_t arithmetic,
 * so no __udivdi3 is needed on this 32-bit target either. */
#include "zxv_decl.h"

static void boot_msg(const char *m) { uart_puts(m); uart_puts("\n"); }

extern void uart_hex(uint32_t val);

/* Fatal exception report, called from the vector stubs in boot.s with the
 * vector number and the exception-mode LR. Before boot.s installed VBAR an
 * abort here jumped to address 0 and the log simply stopped; now it names the
 * fault. "[FAULT]" is the marker the CI boot step treats as a failed boot.
 * Fault status/address registers: DFSR/DFAR (data abort), IFSR/IFAR
 * (prefetch abort), read from CP15. Returns to the stub, which parks. */
void arm32_fault_report(uint32_t vec, uint32_t lr);
void arm32_fault_report(uint32_t vec, uint32_t lr)
{
    static const char *const names[8] = {"reset",
                                         "undefined instruction",
                                         "supervisor call",
                                         "prefetch abort",
                                         "data abort",
                                         "reserved",
                                         "IRQ",
                                         "FIQ"};
    uint32_t fsr = 0, far = 0;
    if (vec == 4u) {
        __asm__ volatile("mrc p15, 0, %0, c5, c0, 0" : "=r"(fsr));
        __asm__ volatile("mrc p15, 0, %0, c6, c0, 0" : "=r"(far));
    } else if (vec == 3u) {
        __asm__ volatile("mrc p15, 0, %0, c5, c0, 1" : "=r"(fsr));
        __asm__ volatile("mrc p15, 0, %0, c6, c0, 2" : "=r"(far));
    }
    uart_puts("\n[FAULT] ARM32 exception: ");
    uart_puts(names[vec & 7u]);
    uart_puts("\n  lr  = ");
    uart_hex(lr);
    uart_puts("\n  fsr = ");
    uart_hex(fsr);
    uart_puts("\n  far = ");
    uart_hex(far);
    uart_puts("\n[FAULT] halted.\n");
}

void kernel_main_arm32(void) {
    uart_init();

    /* RAISE THE CARRIER, first and silently. mb_real_power returns 0 with the
     * line down -- phase is measured RELATIVE to the carrier, so with no
     * reference a phase difference denotes nothing -- and modbind_resolve now
     * couples by real power. Without this the declaration gate below would
     * report every module holding on an unmet requirement, describing a system
     * that had simply not been switched on. Before the gate, not beside it. */
    mb_carrier_up();

    uart_puts("\nZEDEC pqOS — M5 Axiomatic Kernel (VOVINA SHAKINA) [ARM32]\n");
    uart_puts("==================================================\n\n");
    uart_puts("License: Apache-2.0\n");
    uart_puts("Author: H.M. Michael-Laurence: Curzi (c)\n");
    uart_puts("36N9 Genetics, LLC\n\n");
    license_print_all();

    /* M5 core */
    boot_msg("[BOOT] M5 Kernel subsystems...");
    phase_tick_t tick;
    phase_coordinator_init(&tick, EXEC_DC);
    rmag_init(256);
    lpres_init();
    iphase_init();
    choice_handoff();
    oseq_state_t oseq;
    oseq_init(&oseq);
    oseq_register_device(&oseq, "core");
    boot_msg("  [OK] phase/rmag/lpres/iphase/choice/oseq");

    for (int i = 0; i < 5; i++) phase_coordinator_tick(&tick);

    /* Predictive + situation */
    boot_msg("[BOOT] EDP risk + ISF + predictive model...");
    predictive_config_t pred_cfg; predictive_config_init(&pred_cfg);
    boot_msg("  [OK] EDP operators + Fibonacci algebra + ISF surplus");

    /* Nine-capital triple ledger */
    boot_msg("[BOOT] Nine-capital triple ledger...");
    static triple_ledger_t tl; triple_ledger_init(&tl);
    triple_ledger_create_account(&tl, 1, CAP_FINANCIAL,  "Genesis:Financial");
    triple_ledger_create_account(&tl, 1, CAP_HUMAN,      "Genesis:Human");
    triple_ledger_create_account(&tl, 1, CAP_ECOLOGICAL, "Genesis:Ecological");
    boot_msg("  [OK] 9 capital types");

    boot_msg("[BOOT] Financial instruments + payment rails + crypto bridge...");
    static portfolio_t portfolio;   portfolio_init(&portfolio);
    static rail_system_t rail_sys;  rail_system_init(&rail_sys);
    static bridge_registry_t br;    bridge_registry_init(&br);
    boot_msg("  [OK] instruments + 3 rails + bridge");

    boot_msg("[BOOT] Identity + quantum + RTL + JDR PirateNet...");
    static identity_registry_t id_reg; identity_registry_init(&id_reg);
    static quantum_system_t qsys;      quantum_system_init(&qsys);
    static rtl_registry_t rtl_reg;     rtl_registry_init(&rtl_reg);
    static jdr_network_t jdr_net;      jdr_network_init(&jdr_net);
    jdr_register_node(&jdr_net, 1);
    jdr_transceiver_create(&jdr_net, 145000000, 12500,
        JDR_BAND_VHF, JDR_MOD_FM, JDR_EXEC_AC, "JDR-ARM32-001");
    boot_msg("  [OK] identity/quantum/rtl/jdr");

    boot_msg("[BOOT] Vino bank + Vena runtime + holographic data...");
    static vino_ledger_t vino; vino_init(&vino, 1);
    vino_create_account(&vino, "ZEDEC:node:arm32:0001", "Genesis Account");
    vino_set_validator(&vino, true, 1000000);
    static vena_runtime_t vena; vena_init(&vena, &vino);
    vena_set_language(&vena, LANG_M5_AXIOMATIC);
    static holo_ctx_t holo; holo_init(&holo);
    boot_msg("  [OK] vino/vena/holo");

    /* ==== THE REAL DECLARATION GRAPH, AND ITS GATE ==========================
     * ONE CALL, FIVE ARCHITECTURES (kernel/src/modbind/zxv_decl_gate.c).
     *
     * PLACEMENT. On arm64 the gate must sit after the last modbind_reset(): the
     * composition fixture and modbind_selfcheck() each wipe the registry, so a
     * gate registering before them would verify a table that is then erased.
     * MEASURED HERE: this main calls neither, and neither does anything it
     * reaches (`grep -rn modbind kernel/arch/arm32` is empty), so there is no
     * reset to sit after. It goes at arm64's RELATIVE position -- after the
     * subsystem inits, before the BOOT_OK milestone -- rather than at an
     * assumed one, because "after the reset" is a property of the code path.
     *
     * BEFORE [BOOT_OK], not after: the milestone must not be printed while the
     * question of whether the graph is sound is still unasked. */
    (void)zxv_decl_boot_gate(uart_puts);

    /* ==== TOL VOVINA UPAAH LOT — the MegaROM container registers at boot =====
     * boot_features_init() (which runs tvl_rom_register_boot on x86_64/arm64) is
     * not on the ARM32 boot path, so register the MegaROM directly here. It
     * builds the canonical TVUL container, validates it, and takes a real
     * MR_KIND_GAME megarom slot. The identical bytes ship on the attached
     * virtio-blk drive as MEGAROM.TVL; the on-drive READ path is not compiled
     * for this arch, so what registers is the EMBEDDED twin -- stated plainly.
     * Forward-declared so no header path is assumed; both symbols are already
     * linked from tvl_rom.c and megarom.c. uart_dec is the arch decimal printer. */
    {
        extern int tvl_rom_register_boot(void);
        extern int megarom_count(void);
        int mr_slot = tvl_rom_register_boot();
        if (mr_slot >= 0) {
            uart_puts("[MEGAROM] slot ");
            uart_dec((uint32_t)mr_slot);
            uart_puts(": 'TOL VOVINA UPAAH LOT' — MR_KIND_GAME registered "
                      "(container embedded; identical bytes on attached "
                      "virtio-blk drive as MEGAROM.TVL); registry count=");
            uart_dec((uint32_t)megarom_count());
            uart_puts("\n");
        } else {
            uart_puts("[MEGAROM] tvl_rom_register_boot FAILED\n");
        }
    }

    /* ramfb display scanout — draw the ZEDEC desktop. The full compositor chain
     * (prism_break -> display negotiation -> ramfb over fw_cfg -> vbe ->
     * zxv_shell + lattice_dim) is linked into this build but was never CALLED
     * here; arm64 alone reached it. zxv_render_boot() is that missing call site,
     * shared with the riscv main. Geometry negotiated from real capability
     * limits, never hardcoded. Absent `-device ramfb`, ramfb_init returns <0 and
     * we stay on serial -- an honest headless boot, not a failure. arm/virt
     * fw_cfg MMIO is the ramfb default base (0x09020000), so no override needed. */
    {
        extern int zxv_render_boot(void (*log)(const char *));
        (void)zxv_render_boot(boot_msg);
    }

    boot_msg("\n[BOOT_OK] ZEDEC pqOS [ARM32] — core online. Entering event cycle.\n");

    /* Core bring-up event loop. We pace off the generic-timer virtual counter
     * (readable at PL1) rather than a timer IRQ — the GIC is not wired up in this
     * profile, so a bare `wfi` would sleep forever with no wakeup source. */
    uint32_t cycle = 0;
    uint32_t freq = arm32_cntfrq();
    uint32_t period = freq ? (freq / 100u) : 625000u;   /* ~100 Hz; fallback 62.5 MHz/100 */
    uint64_t last = arm32_cntvct();
    while (1) {
        uint64_t now;
        do { now = arm32_cntvct(); } while ((uint32_t)(now - last) < period);
        last += period;
        phase_coordinator_tick(&tick);
        if (cycle % 100 == 0) { uart_puts("tick: omega="); uart_dec(tick.omega); uart_puts("\n"); }
        cycle++;
    }
}
