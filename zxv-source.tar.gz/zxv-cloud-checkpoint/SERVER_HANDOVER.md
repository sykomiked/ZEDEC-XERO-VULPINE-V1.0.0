<!--
Copyright (c) 2024-2026 Michael Laurence Curzi and 36N9 Genetics, LLC
SPDX-License-Identifier: Apache-2.0
-->

# ZEDEC pqOS — Server Cross-Compile Handover Schema

**For: the AI operator who will run the cross-compile on a Linux server.**
**From: the development session on Apple Silicon (arm64 macOS).**
**Repo root for every command below: `05_KERNEL/` (the git root).**

---

## ★ CURRENT DELIVERABLE STATE — 2026-08-11 (READ THIS FIRST; supersedes older sections)

The five-architecture kernel is **assembled and emulation-verified**. One command on the
Linux box reproduces the whole thing:

```bash
bash build_system/build_all.sh      # from 05_KERNEL/ on the Linux build box
```

It cleans (`rm -rf build`), builds all five arches **concurrently** out-of-tree (`-j`), runs
**both** static gates (DRC `verify_layers.sh` + LVS `verify_banners.sh` per ELF), boots **six**
QEMU rows for 30 s (`rc=124` == still-running == PASS), and prints the PASS/FAIL matrix.
Toolchains are **discovered** (each Makefile's own default + `which`), nothing hardcoded.

**Result of the clean run (git `50784c6`):** every row **PASS** —

| row | build | DRC | LVS | boot | BOOT_OK | modbind gate | fault |
|---|---|---|---|---|---|---|---|
| arm64 GICv3 | rc0 | PASS | PASS | 124/up | yes | OK (88=88) | none |
| arm64 GICv2 | rc0 | PASS | PASS | 124/up | yes | OK (88=88) | none |
| x86_64 | rc0 | PASS | PASS | 124/up | yes | OK (38=38) | none |
| riscv64 (Sv39) | rc0 | PASS | PASS | 124/up | yes | OK (38=38) | none |
| riscv32 (Sv32) | rc0 | PASS | PASS | 124/up | yes | OK (38=38) | none |
| arm32 | rc0 | PASS | PASS | 124/up | yes | OK (39=39) | none¹ |

¹ arm32 `arm32_mmu` reports **S0 HELD** (MMU off, flat-physical) — honest, not a fault.

- **Full provenance:** [`PROVENANCE/KERNEL_DELIVERABLE.md`](PROVENANCE/KERNEL_DELIVERABLE.md)
  (matrix, per-arch gate detail, available-basis figures, exact QEMU invocations, and an
  explicit "does NOT claim").
- **Captured run output:** [`PROVENANCE/build_all_output.txt`](PROVENANCE/build_all_output.txt).
- **Staged artifacts:** `~/zxv/deliverable/` on the box — five ELF + five `.bin` with sizes and
  sha256 in `MANIFEST.txt` (mirror: [`PROVENANCE/DELIVERABLE_MANIFEST.txt`](PROVENANCE/DELIVERABLE_MANIFEST.txt)).
- **Signature:** UNSIGNED (pending). The offline Ed25519 root ceremony is a separate,
  deliberate step (`sign_release_offline.sh` + `keyceremony_root.sh`) — never minted in a
  build session, never faked.

**What changed since the 2026-08-08 sections below (now historical):** x86_64 is no longer
"minimal kernel-only" — it boots with ring-3 (GDT/TSS/IDT + `int 0x80` syscall) and PML4
paging. riscv/riscv32/arm32 are no longer "unproven locally" — all build, link and boot on
the box with the runtime modbind gate green. The `x86_64-ring3` P0 work item is **resolved**.
Still open below: EFI payloads, universal disc/VM, and the signed release. Machine-readable
mirror of all this: [`build_system/handover.json`](build_system/handover.json) (`deliverable`
block, schema 1.3.0).

---

## Phase A hardening — DONE on the Mac before this handover (2026-08-08)

The following were completed and verified host-side (see `PROVENANCE/REMAINING_WORK_MAP.md`
and commit `bcf1c5f`). You are receiving an already-MVP-hardened tree:

- **Preflight CLEAN** across all 5 targets. **arm64 build has 0 warnings** (compiler + linker).
- **32-bit source/compile parity**: `arm32` (194 files) and `riscv32` (196) now carry the
  full portable subsystem set (was ~50). One real 32-bit bug fixed (`broker.c` `__uint128_t`).
  Only 3 arch-dependent files deferred to you (`el0_sched`, `video/ramfb`, `virtio_bus`).
- **Security P0s** (host/arm64-verified, all in `verify-all`):
  - P0-4 EL0 user-copy: `copy_to_user`, SYS_SEND copies-to-kernel, SYS_OPEN/CLOSE ENOSYS.
  - P0-6 signed-exec: **ZSP v2** rich authenticated header (version/arch/abi/caps/key-id/
    identity) + `zsp_verify2` + **monotonic anti-rollback floor** (`test_zsp2`).
  - P0-3 durability (partial): A/B persists the rollback floor + authenticated version,
    crash-ordered writes (`test_abupdate` extended). *A/B for kernel+bootloader images is
    still yours (needs the boot payloads).*
  - P0-2 installer: manifest **Ed25519-authenticated, fail-closed** + path/symlink
    confinement (`install_security` in verify-all; `sign_manifest.sh`).

**Your P0s remain**: x86_64 ring-3 parity, the 32-bit **arch layer + link + boot**, EFI
payloads, universal disc/VM, and the offline-key signed release. See `work_items` below.

---

This document is the contract. It says exactly what is already proven, what you
must do, the order to do it in, and how to know you succeeded. It is written to
the project's governing rule: **no hollow capabilities** — never report a target
as working unless an artifact was produced and a gate passed. A missing
toolchain is a `SKIP`, a compile error is a `FAIL`, only a produced-and-verified
artifact is `OK`.

A machine-readable version of this schema is at
[`build_system/handover.json`](build_system/handover.json) — parse that if you
want to drive the build programmatically.

---

## 0. TL;DR

```bash
# from 05_KERNEL/, on a fresh Ubuntu/Debian box:
bash build_system/provision_server.sh              # 1. toolchains
bash build_system/preflight_all_targets.sh         # 2. compile smoke-test every arch (clang)
bash build_system/build_all_targets.sh             # 3. LINK every arch that has a toolchain
bash build_system/ci_gate.sh 100                   # 4. fail-closed gate (build+verify+fuzz+100 boots)
bash build_system/mkuniversal_disc.sh              # 5. one disc, all chips (UEFI multi-arch)
bash build_system/mkuniversal_vm.sh                # 6. one VM file, all hypervisors
# 7. sign the native-format release (needs the root key — see §6)
ROOT_KEY=/secure/root_priv.pem bash build_system/sign_release.sh
```

If every step above ends green, you are done. The rest of this document is what
to do when they don't, and the two subsystems that need real work (§3).

---

## 1. Ground truth — what is already verified, and where

The **arm64 target is the reference build**. It compiles and boots to
`[E0106] [BOOT_OK]` (EL0 + P-TERM shell) on the dev machine under
`qemu-system-aarch64`, with the platform layer (`8/8`) **and** the economy
foundation (`5/5`) self-checking at boot. Everything below is measured, not
asserted.

| Layer | Status on handover | How it was verified |
|---|---|---|
| M5 core (phase coord, rmag, lpres, iphase, choice, oseq) | ✅ boots | arm64 QEMU → BOOT_OK |
| Network (DHCP/DNS/TCP), TLS 1.3 (HKDF/X25519/ChaCha20-Poly1305) | ✅ host-tested vs RFC vectors | `make verify-all` |
| Tri-Space pkg (.zxvc/.cedez/.cedec) + ZSP Ed25519 verify | ✅ host-tested vs openssl sigs | `make verify-all` |
| **Platform layer** (deploy, theme, icon, font+TrueType, bridge, update, mage, reality) | ✅ **boots on arm64**, host-tested | `[FEAT] … 8/8 self-checked` in boot log + `make verify-all` |
| **Economy/governance/social layer** (25 modules: onepolicy, zcapital, vino_stores, crown, ministry, battering_ram, finance_markets, iso20022, alloc, logistics, concord, social, reputation, pirate_fleet, pirate_apps, chiglet-suite, orbital_compat, sutra, …) | ✅ **boots on arm64**, host-tested | `[FEAT] economy foundation up: 5/5` in boot log + `make verify-all` |
| Font system (script itemization + TrueType rasteriser) | ✅ host-tested, known-answer | `test_truetype`, `test_font` |
| Web2/3/4 bridge (one resolver) | ✅ host-tested | `test_bridge` |
| Host integrity gate | ✅ **ALL STAGE-1 CHECKS PASSED** (3593 checks, 0 failures) | `make verify-all` from `kernel/` |
| 5-target cross-compile preflight | ✅ **CLEAN** (arm64 170 files incl. economy layer; x86_64/riscv/riscv32/arm32 compile) | `preflight_all_targets.sh` (clang, compile-only) |
| Adversarial red-team (two gates) | ✅ **31 findings fixed** (19 kernel-layer `953e3ae` + 12 economy-layer `15f5455`), each with a frozen regression | `make verify-all` under ASan/UBSan |

**Definition of "host-tested":** a native `gcc`/`clang` test binary asserts
computed values against an external anchor (an RFC vector, an openssl-produced
signature, a known-answer geometry), run under ASan+UBSan. `make verify-all`
(run from `05_KERNEL/kernel/`) is the aggregate gate and it is green.

---

## 2. The target matrix

`build_all_targets.sh` builds these (`TARGETS="arm64 x86_64 riscv riscv32 arm32"`):

| Target | Makefile | Toolchain (apt) | Local status | Server action |
|---|---|---|---|---|
| **arm64** | `build_system/Makefile.arm64` | `gcc-aarch64-linux-gnu` | ✅ builds + boots | rebuild & confirm parity |
| **x86_64** | `build_system/Makefile.x86_64` | `gcc-x86-64-linux-gnu` | ⚠️ compiles, **minimal kernel_main** | **§3 — real work** |
| **riscv64** | `build_system/Makefile.riscv` | `gcc-riscv64-linux-gnu` | ⚠️ not linkable locally (host clang lacks RISCV) | build & boot-test |
| **riscv32** | `build_system/Makefile.riscv32` | `gcc-riscv64-linux-gnu` (multilib) | ⚠️ same | build & boot-test |
| **arm32** | `build_system/Makefile.arm32` | `gcc-arm-linux-gnueabihf` | ⚠️ compiles | build & boot-test |

The dev machine is Apple Silicon with **only** an aarch64 GNU cross-toolchain
and a clang that lacks the RISCV backend. That is the sole reason the other four
are unproven here — **not** a code defect. `preflight_all_targets.sh` (clang,
compile-only) is the smoke test that catches portability defects before you
spend server time on linking.

---

## 3. What needs REAL work on the server (not just a rebuild)

Two items cannot be finished on Apple Silicon and were deliberately left for you.
Do **not** treat these as done.

### 3a. x86_64 ring-3 parity — the one true gap
`kernel/arch/x86_64/` has a **minimal** `kernel_main` (bootstrap only): no
ring-3/EL0-equivalent, no per-process page tables, no syscall path. The
arch-neutral modules (elf, zsp, zxvfs, the whole platform layer) are portable and
host-tested, but **x86_64 has no userspace yet**. To reach parity with arm64:
- page tables (PML4) + user/supervisor split,
- a syscall entry (`syscall`/`sysret`) mirroring the arm64 SVC path,
- a ring-3 process bring-up mirroring `arch/arm64/el0_userspace.c`,
- then wire the platform layer (§4) and confirm `[BOOT_OK]` under `qemu-system-x86_64`.

Until then, report x86_64 as **"boots, kernel-only"** — never as full parity.

### 3b. EFI boot payloads for the universal disc
`mkuniversal_disc.sh` assembles a GPT + FAT32 ESP and expects per-arch payloads
at `/EFI/BOOT/BOOTX64.EFI`, `BOOTAA64.EFI`, `BOOTRISCV64.EFI`. The mechanism is
real (UEFI removable-media multi-arch boot), but each arch's kernel must be
wrapped as (or chainloaded by) a UEFI PE binary. Produce the `.EFI` stubs
(GNU-EFI or a PE64 wrapper that loads the kernel blob) and drop them where the
script expects. The script documents the exact paths at its top.

### 3c. Wire the platform AND economy layers into the non-arm64 arches
arm64 already boots both layers (the `[FEAT]` lines: platform `8/8`, economy
`5/5`). x86_64/riscv/arm32 are bring-up/preflight kernels that do **not** yet
carry them. Each layer is a self-contained includable fragment; wiring is the
same two-edit pattern per layer:
```make
include build_system/platform_layer.mk      # 11 platform modules
include build_system/economy_layer.mk        # 25 economy/governance/social modules
KERNEL_SRCS += $(PLATFORM_LAYER_SRCS) $(ECONOMY_LAYER_SRCS)
CFLAGS      += $(PLATFORM_LAYER_INC)  $(ECONOMY_LAYER_INC)
```
and in that arch's `kernel_main`, just before its BOOT_OK milestone:
```c
#include "boot_features.h"
boot_features_init(<that_arch_uart_puts>, <cpu_cores_or_0>, <mem_mb_or_0>);
boot_economy_init(<that_arch_uart_puts>);    // rolls up the 5/5 economy foundation
```
**Order of operations matters.** The economy layer builds ON base modules that
must already be in that arch's `KERNEL_SRCS` — `finance/triple_ledger`, `surplus`,
`robin_debanks/{sha256,ed25519_verify}`, `concord`, `chiglet`, `trispace`,
`constellation`, `identity`, `theme`, `icon`, `cards/sigil`, `tls/hkdf`. The
x86_64 kernel is currently minimal (§3a), so bring those base modules up first
(they are already in arm64's list and in `platform_layer.mk`) or the economy
layer will report undefined symbols — that is a missing base dep, not a bug in
the fragment. All 25 economy modules already compile freestanding under the
five-target preflight; the work is linking them onto a full-featured kernel_main.

---

## 4. Native-format artifacts + contingency for bugs

The compiled product must render programs in the **native Tri-Space formats**
(`.zxvc` = S+, `.cedez` = S−, `.cedec` = S0), not raw ELF. The pipeline:
- `build_system/mkzxpkg.c` — compile it (`cc -O2 mkzxpkg.c -o mkzxpkg`), it emits
  the `.seal` (the triad binding: all 5 hard requirements enforced by `tri_bind`).
- `build_system/sign_release.sh` — wraps the seal in a ZSP Ed25519 envelope
  (magic `ZSP1`); on-target `zxpkg_verify_release` checks triad-intact **and**
  signature-vs-root-key. This is **proven** to reproduce the test fixture.

**Contingency doctrine (already built in, keep it):** the loader and ops
boundaries **fail closed, never fake**. If a native artifact is malformed, the
loader returns not-bound rather than executing garbage; the font stack returns
"no glyph" rather than a fabricated box; the bridge returns `NOT_BOUND` rather
than an invented address. When you add the x86_64 loader path, preserve this: a
bug must degrade to a refusal with a diagnostic, not a silent wrong result. The
parser fuzzers in `ci_gate.sh` (ELF, ZXVFS, under ASan+UBSan) are the guard —
keep them green.

---

## 5. The universal artifacts

- **One disc, all chips** — `mkuniversal_disc.sh`. Not a fat binary (no CPU runs
  another's machine code); it is UEFI's multi-arch ESP. Needs §3b payloads.
  Boot-test each arch's firmware in QEMU with the matching OVMF/edk2 (`ovmf` for
  x86_64; build/fetch AAVMF for arm64, RISC-V edk2 for riscv).
- **One VM file, all hypervisors** — `mkuniversal_vm.sh`. The raw image *is* the
  universal disc; it also emits `zxv.ova` (DMTF standard) and, if `qemu-img` is
  present, `qcow2/vmdk/vhdx/vdi`. This path is **proven end-to-end** with
  `qemu-img` on the dev machine — the conversions work; they just need the real
  disc (§3b) as input.

---

## 6. Signing & secrets — READ BEFORE YOU BUILD

- The **Ed25519 root key is NOT in the repo** and must never be. `sign_release.sh`
  takes it via `ROOT_KEY=/secure/root_priv.pem`. `build_system/keys/root_priv.pem`
  is a **dev-only, gitignored** placeholder — do not ship anything signed with it.
- **SSH keys pasted in an earlier session are COMPROMISED — rotate them.** Never
  paste any private key, SSH key, or credential into an AI prompt (including
  mine). Generate/hold keys on the server; the operator handles them out-of-band.
- Choose privacy-preserving options; never put secrets in URLs or env dumps that
  get logged.

---

## 7. Definition of done (acceptance criteria)

Report the build complete only when **all** of these hold, each with evidence:

1. `preflight_all_targets.sh` → every target **compiles** (matrix printed).
2. `build_all_targets.sh` → every target with a toolchain **links** to an artifact
   (arm64 + x86_64 mandatory; riscv/arm32 OK-or-SKIP with reason).
3. `ci_gate.sh 100` → clean build **+** `verify-all` green **+** fuzzers green **+**
   100/100 arm64 boots reach `BOOT_OK` with no fault. Fail-closed: a missing
   required step fails the gate.
4. x86_64 boots under `qemu-system-x86_64` to its BOOT_OK (kernel-only is
   acceptable **if labelled**; full ring-3 parity is the goal — §3a).
5. `mkuniversal_disc.sh` → a disc that boots on ≥2 arches' firmware in QEMU.
6. `mkuniversal_vm.sh` → `zxv.raw` + `zxv.ova` produced; opens in ≥1 hypervisor.
7. A signed native-format release verifies with `zxpkg_verify_release` against
   the **real** root key.

For anything you cannot complete, say so explicitly with the reason and the
matrix cell — do not round up. That honesty is the deliverable.

---

## 8. Orientation — where things are

- Canonical source tree: `05_KERNEL/kernel/` (`arch/`, `src/`, `boot/`, `compat/`).
- **Architecture reference: [`ARCHITECTURE_WHITEPAPER.md`](ARCHITECTURE_WHITEPAPER.md)** —
  the whole-system design (axioms, the 10 layers, cross-cutting invariants, the two
  red-team gates, and this build pipeline). Read it first for the *why*; this
  handover is the *how*. File index: `SUBSYSTEM_INDEX.md`.
- Reference build: `build_system/Makefile.arm64`. Host gate: `kernel/Makefile`
  (`make verify-all`). Layer fragments: `platform_layer.mk`, `economy_layer.mk`.
- Platform + economy layer entry: `kernel/src/bootfeat/boot_features.c`
  (`boot_features_init` and `boot_economy_init`), both called from
  `kernel/arch/arm64/kernel_main_arm64.c` just before `[BOOT_OK]`.
- **Red-team guards are load-bearing — never remove them.** Two adversarial gates
  fixed 31 findings, each with a frozen regression in the relevant `test_*.c`
  (run under ASan/UBSan by `make verify-all`). The economy-layer invariants to
  preserve: escrow/settlement ops boundaries verify a *signature + membership* and
  fail closed when unbound (`log_set_verifier`, `br_distribute`, `crown_isc_is_active`);
  the One Policy extraction check ignores the caller-set `reciprocal` flag; a
  ledger post asks a *pure usury query*, not the two-party deal gate; money legs
  require a bound rail (`BR_ERR_NO_RAIL`); quarantine needs distinct-reporter
  consensus and `soc_sort` never manufactures it. See the white paper §14.
- Do **not** treat `zxv_os/`, `zxv_build/`, `zxv_complete/`, `zxv_sdk/`,
  `05_KERNEL/subsystems/` as canonical — they are archived/partial snapshots,
  kept intentionally, not the source of truth.
- Licensing: `LICENSE` (Apache-2.0). SPDX headers are on the sources. Preserve them.

Good building. Keep it honest, keep it fail-closed, and label anything you could
not verify.
